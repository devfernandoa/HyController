# Mock Hytale Assets
